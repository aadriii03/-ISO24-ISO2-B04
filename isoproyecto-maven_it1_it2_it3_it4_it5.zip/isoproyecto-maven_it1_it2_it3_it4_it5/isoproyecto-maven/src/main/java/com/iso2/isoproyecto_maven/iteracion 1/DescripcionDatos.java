package com.iso2.isoproyecto_maven;

import java.util.ArrayList;
import java.util.List;

// Clase para CDU11: Describir Datos Mediante Metadatos
public class DescripcionDatos {

    private List<DescripcionNivel> descripciones;

    public DescripcionDatos() {
        this.descripciones = new ArrayList<>();
    }

    // RF3.1: Descripción de activos en varios niveles (conceptual, lógico, físico)
    public void agregarDescripcion(String nivel, String nombre, String detalle) {
        descripciones.add(new DescripcionNivel(nivel, nombre, detalle));
    }

    // RF3.2: Exportar metadatos en distintos formatos (simplificado)
    public void exportarDescripciones(String formato) {
        System.out.println("Exportando en formato: " + formato);
        descripciones.forEach(d -> System.out.println(d.toString()));
    }

    // RNF3.1: Estructura clara y coherente para cada nivel
    private class DescripcionNivel {
        private String nivel;
        private String nombre;
        private String detalle;

        public DescripcionNivel(String nivel, String nombre, String detalle) {
            this.nivel = nivel;
            this.nombre = nombre;
            this.detalle = detalle;
        }

        @Override
        public String toString() {
            return "Nivel: " + nivel + ", Nombre: " + nombre + ", Detalle: " + detalle;
        }
    }
}

