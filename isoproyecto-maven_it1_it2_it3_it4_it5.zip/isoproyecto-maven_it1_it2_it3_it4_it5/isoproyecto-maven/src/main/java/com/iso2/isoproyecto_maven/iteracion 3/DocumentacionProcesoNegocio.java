import java.util.Date;
import java.util.HashMap;
import java.util.Map;

// Clase para CDU2: Documentar los procesos de negocio en los que se usan esos datos
public class DocumentacionProcesoNegocio {

    private String nombreProceso;
    private String descripcion;
    private Date fechaDocumentacion;
    private Map<String, String> datosAsociados;  // Datos y su descripción dentro del proceso

    public DocumentacionProcesoNegocio(String nombreProceso, String descripcion) {
        this.nombreProceso = nombreProceso;
        this.descripcion = descripcion;
        this.fechaDocumentacion = new Date();
        this.datosAsociados = new HashMap<>();
    }

    // RF.PD.08: Documentar un proceso de negocio
    public void agregarDatoAlProceso(String nombreDato, String descripcionDato) {
        datosAsociados.put(nombreDato, descripcionDato);
    }

    public void mostrarDocumentacion() {
        System.out.println("Proceso de Negocio: " + nombreProceso);
        System.out.println("Descripción: " + descripcion);
        System.out.println("Fecha de Documentación: " + fechaDocumentacion);
        datosAsociados.forEach((dato, descripcion) -> 
            System.out.println("Dato: " + dato + " - Descripción: " + descripcion)
        );
    }
}
