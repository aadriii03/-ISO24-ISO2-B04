package com.iso2.isoproyecto_maven;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;

// Clase para CDU1: Elaborar un Mapa de Activos de Datos
public class MapaActivoDatos {

    private List<String> activosDatos;
    private Map<String, List<String>> categorias;

    public MapaActivoDatos(List<String> inventarioInicial, Map<String, List<String>> categoriasInicial) {
        this.activosDatos = inventarioInicial;
        this.categorias = categoriasInicial;
    }

    // RF1.1: Permitir la incorporación de nuevos activos
    public void agregarActivo(String activo, String categoria) {
        activosDatos.add(activo);
        categorias.computeIfAbsent(categoria, k -> new ArrayList<>()).add(activo);
    }

    // RF1.2: Almacenar y categorizar activos según criterios predefinidos
    public void categorizarActivo(String activo, String nuevaCategoria) {
        if (activosDatos.contains(activo)) {
            categorias.get(nuevaCategoria).add(activo);
        }
    }

    // RNF1.1: Visualización intuitiva y navegable (simplificado)
    public void mostrarMapa() {
        System.out.println("Mapa de Activos de Datos:");
        categorias.forEach((categoria, activos) -> {
            System.out.println("Categoría: " + categoria);
            activos.forEach(System.out::println);
        });
    }
}
