package com.iso2.isoproyecto_maven;

import java.util.ArrayList;
import java.util.List;

// Clase para CDU8: Crear Nuevos Metadatos de Negocio, Técnicos y Operativos
public class Metadatos {

    private List<Metadato> metadatos;

    public Metadatos() {
        this.metadatos = new ArrayList<>();
    }

    // RF2.1: Permitir creación de metadatos de diferentes tipos
    public void crearMetadato(String tipo, String nombre, String descripcion) {
        metadatos.add(new Metadato(tipo, nombre, descripcion));
    }

    // RF2.2: Almacenar y gestionar metadatos estructurados
    public List<Metadato> obtenerMetadatos() {
        return metadatos;
    }

    // RNF2.1: Tiempo real sin afectar rendimiento (simplificado)
    public void actualizarMetadato(String nombre, String nuevaDescripcion) {
        metadatos.stream()
                .filter(m -> m.getNombre().equals(nombre))
                .findFirst()
                .ifPresent(m -> m.setDescripcion(nuevaDescripcion));
    }

    // Clase interna para representar un Metadato
    private class Metadato {
        private String tipo;
        private String nombre;
        private String descripcion;

        public Metadato(String tipo, String nombre, String descripcion) {
            this.tipo = tipo;
            this.nombre = nombre;
            this.descripcion = descripcion;
        }

        public String getNombre() { return nombre; }
        public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    }
}

