import java.util.List;
import java.util.ArrayList;

// Clase para CDU6: Definir dominios de datos
public class DominioDatos {

    private String nombre;
    private String descripcion;
    private List<String> conjuntosDatos;

    public DominioDatos(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.conjuntosDatos = new ArrayList<>();
    }

    // RF.PD.04: Selección de conjuntos de datos para el dominio
    public void agregarConjuntoDatos(String conjuntoDatos) {
        if (!conjuntosDatos.contains(conjuntoDatos)) {
            conjuntosDatos.add(conjuntoDatos);
        } else {
            System.out.println("El conjunto de datos ya está asignado a este dominio.");
        }
    }

    // Verifica si el dominio existe para evitar duplicados
    public boolean verificarExistencia(String nombreDominio) {
        return this.nombre.equals(nombreDominio);
    }

    // Mostrar información del dominio
    public void mostrarInformacion() {
        System.out.println("Dominio: " + nombre + "\nDescripción: " + descripcion);
        conjuntosDatos.forEach(System.out::println);
    }
}
