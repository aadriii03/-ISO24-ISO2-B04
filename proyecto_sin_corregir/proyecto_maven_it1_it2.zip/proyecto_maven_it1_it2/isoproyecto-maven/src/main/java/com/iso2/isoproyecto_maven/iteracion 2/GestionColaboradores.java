import java.util.List;
import java.util.Map;

// Clase para CDU4: Identificar quién está implicado en los proyectos de los datos
public class GestionColaboradores {

    private Map<String, List<Colaborador>> proyectosColaboradores;  // Mapa de proyectos y colaboradores asociados
    private Map<Colaborador, String> permisosColaboradores;  // Colaboradores y sus permisos de acceso

    // RF.PD.02: Selección de colaboradores para el proyecto
    public void agregarColaboradorAProyecto(String idProyecto, Colaborador colaborador, String permiso) {
        proyectosColaboradores.computeIfAbsent(idProyecto, k -> new ArrayList<>()).add(colaborador);
        permisosColaboradores.put(colaborador, permiso);
    }

    // Método para validar permisos
    public boolean validarPermiso(Colaborador colaborador, String permiso) {
        return permisosColaboradores.getOrDefault(colaborador, "").equals(permiso);
    }

    // Flujo alternativo: manejo de errores en permisos
    public void gestionarErrorPermiso(String mensaje) {
        System.out.println("Error: " + mensaje);
    }
}

// Clase auxiliar Colaborador
class Colaborador {
    private String nombre;
    private String rol;

    public Colaborador(String nombre, String rol) {
        this.nombre = nombre;
        this.rol = rol;
    }

    // Getters y setters
    public String getNombre() { return nombre; }
    public String getRol() { return rol; }
}
