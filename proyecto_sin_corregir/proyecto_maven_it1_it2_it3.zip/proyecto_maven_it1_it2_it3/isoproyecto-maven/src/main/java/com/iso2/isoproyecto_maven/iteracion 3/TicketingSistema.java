import java.util.HashMap;
import java.util.Map;

// Clase para CDU13: Asignar tareas mediante un sistema de ticketing
public class TicketingSistema {

    private Map<String, Tarea> tareasAsignadas;  // ID de tarea y detalles de la tarea

    public TicketingSistema() {
        this.tareasAsignadas = new HashMap<>();
    }

    // RF.PD.06: Asignar tareas a través del sistema de ticketing
    public void asignarTarea(String idTarea, String descripcion, String asignadoA) {
        Tarea nuevaTarea = new Tarea(idTarea, descripcion, asignadoA);
        tareasAsignadas.put(idTarea, nuevaTarea);
        System.out.println("Tarea asignada: " + idTarea + " a " + asignadoA);
    }

    public void mostrarTareasAsignadas() {
        System.out.println("Listado de tareas asignadas:");
        tareasAsignadas.values().forEach(Tarea::mostrarDetalles);
    }
}

// Clase auxiliar Tarea
class Tarea {
    private String id;
    private String descripcion;
    private String asignadoA;

    public Tarea(String id, String descripcion, String asignadoA) {
        this.id = id;
        this.descripcion = descripcion;
        this.asignadoA = asignadoA;
    }

    // Mostrar detalles de la tarea
    public void mostrarDetalles() {
        System.out.println("ID Tarea: " + id + ", Descripción: " + descripcion + ", Asignado a: " + asignadoA);
    }
}
