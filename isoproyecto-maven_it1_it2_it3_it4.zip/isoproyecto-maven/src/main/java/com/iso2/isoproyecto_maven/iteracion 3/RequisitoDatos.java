import java.util.ArrayList;
import java.util.List;

// Clase para CDU3: Identificar y documentar los requisitos de datos
public class RequisitoDatos {

    private String nombreRequisito;
    private String descripcion;
    private List<String> datosNecesarios;

    public RequisitoDatos(String nombreRequisito, String descripcion) {
        this.nombreRequisito = nombreRequisito;
        this.descripcion = descripcion;
        this.datosNecesarios = new ArrayList<>();
    }

    // RF.PD.03: Identificar y documentar requisitos específicos de datos
    public void agregarDatoRequerido(String dato) {
        datosNecesarios.add(dato);
    }

    public void mostrarRequisito() {
        System.out.println("Requisito de Datos: " + nombreRequisito);
        System.out.println("Descripción: " + descripcion);
        System.out.println("Datos Necesarios: ");
        datosNecesarios.forEach(System.out::println);
    }
}
