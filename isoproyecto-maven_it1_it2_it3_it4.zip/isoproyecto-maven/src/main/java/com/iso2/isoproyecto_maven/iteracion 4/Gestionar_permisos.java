package com.iso2.isoproyecto_maven;

import java.util.*;

//Enum para definir los roles del sistema
enum Role {
 USUARIO_METADATOS,
 GESTOR_SEGURIDAD
}

//Enum para definir los permisos disponibles
enum Permission {
 ACCESO_ACTIVOS,
 GESTIONAR_PERMISOS,
 COMPARTIR_METADATOS,
 AUTORIZACION
}

//Clase que representa a un usuario del sistema
class User {
 private String username;
 private Role role;
 private Set<Permission> permissions;

 public User(String username, Role role) {
     this.username = username;
     this.role = role;
     this.permissions = new HashSet<>();
     // Asignar permisos básicos según el rol
     asignarPermisosPorRol();
 }

 private void asignarPermisosPorRol() {
     switch (this.role) {
         case USUARIO_METADATOS:
             this.permissions.add(Permission.ACCESO_ACTIVOS);
             this.permissions.add(Permission.COMPARTIR_METADATOS);
             this.permissions.add(Permission.AUTORIZACION);
             break;
         case GESTOR_SEGURIDAD:
             this.permissions.add(Permission.GESTIONAR_PERMISOS);
             this.permissions.add(Permission.ACCESO_ACTIVOS);
             break;
         default:
             break;
     }
 }

 public String getUsername() {
     return username;
 }

 public Role getRole() {
     return role;
 }

 public Set<Permission> getPermissions() {
     return permissions;
 }

 public void addPermission(Permission permission) {
     this.permissions.add(permission);
 }

 public void removePermission(Permission permission) {
     this.permissions.remove(permission);
 }

 public boolean hasPermission(Permission permission) {
     return this.permissions.contains(permission);
 }
}

//Clase que gestiona el control de acceso
class AccessControlManager {
 private Map<String, User> users;

 public AccessControlManager() {
     this.users = new HashMap<>();
 }

 // Método para añadir un nuevo usuario al sistema
 public void addUser(String username, Role role) {
     if (users.containsKey(username)) {
         System.out.println("El usuario ya existe.");
     } else {
         User user = new User(username, role);
         users.put(username, user);
         System.out.println("Usuario añadido: " + username + " con rol " + role);
     }
 }

 // Método para asignar un permiso a un usuario (solo para Gestores de Seguridad)
 public void assignPermission(String gestorUsername, String targetUsername, Permission permission) {
     User gestor = users.get(gestorUsername);
     if (gestor == null) {
         System.out.println("Gestor de seguridad no encontrado.");
         return;
     }
     if (gestor.getRole() != Role.GESTOR_SEGURIDAD) {
         System.out.println("El usuario no tiene permisos para asignar permisos.");
         return;
     }
     User target = users.get(targetUsername);
     if (target == null) {
         System.out.println("Usuario objetivo no encontrado.");
         return;
     }
     target.addPermission(permission);
     System.out.println("Permiso " + permission + " asignado a " + targetUsername);
 }

 // Método para revocar un permiso a un usuario (solo para Gestores de Seguridad)
 public void revokePermission(String gestorUsername, String targetUsername, Permission permission) {
     User gestor = users.get(gestorUsername);
     if (gestor == null) {
         System.out.println("Gestor de seguridad no encontrado.");
         return;
     }
     if (gestor.getRole() != Role.GESTOR_SEGURIDAD) {
         System.out.println("El usuario no tiene permisos para revocar permisos.");
         return;
     }
     User target = users.get(targetUsername);
     if (target == null) {
         System.out.println("Usuario objetivo no encontrado.");
         return;
     }
     target.removePermission(permission);
     System.out.println("Permiso " + permission + " revocado a " + targetUsername);
 }

 // Método para verificar si un usuario tiene un permiso específico
 public boolean checkPermission(String username, Permission permission) {
     User user = users.get(username);
     if (user == null) {
         System.out.println("Usuario no encontrado.");
         return false;
     }
     return user.hasPermission(permission);
 }

 // Método para mostrar los permisos de un usuario
 public void showUserPermissions(String username) {
     User user = users.get(username);
     if (user == null) {
         System.out.println("Usuario no encontrado.");
         return;
     }
     System.out.println("Permisos de " + username + ": " + user.getPermissions());
 }
}

//Clase de prueba para demostrar el funcionamiento
public class Main {
 public static void main(String[] args) {
     AccessControlManager acm = new AccessControlManager();

     // Añadir usuarios
     acm.addUser("alice", Role.GESTOR_SEGURIDAD);
     acm.addUser("bob", Role.USUARIO_METADATOS);
     acm.addUser("carol", Role.USUARIO_METADATOS);

     // Mostrar permisos iniciales
     acm.showUserPermissions("alice");
     acm.showUserPermissions("bob");
     acm.showUserPermissions("carol");

     // Gestor de seguridad asigna un nuevo permiso a un usuario de metadatos
     acm.assignPermission("alice", "bob", Permission.AUTORIZACION);

     // Mostrar permisos después de la asignación
     acm.showUserPermissions("bob");

     // Verificar permisos
     System.out.println("¿Bob tiene permiso de AUTORIZACION? " + acm.checkPermission("bob", Permission.AUTORIZacion));

     // Gestor de seguridad revoca un permiso
     acm.revokePermission("alice", "bob", Permission.AUTORIZacion);

     // Mostrar permisos después de la revocación
     acm.showUserPermissions("bob");
 }
}

