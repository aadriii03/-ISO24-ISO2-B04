import java.util.List;

// Clase para CDU10: Descubrir datos contenidos en las bases de datos
public class DescubrimientoDatos {

    private List<String> basesDeDatos;
    private String baseDatosSeleccionada;

    public DescubrimientoDatos(List<String> basesDisponibles) {
        this.basesDeDatos = basesDisponibles;
    }

    // RF.ID.04: Seleccionar y descubrir datos en la base de datos
    public void seleccionarBaseDatos(String baseDatos) {
        if (basesDeDatos.contains(baseDatos)) {
            this.baseDatosSeleccionada = baseDatos;
            System.out.println("Base de datos seleccionada: " + baseDatosSeleccionada);
        } else {
            System.out.println("Error: La base de datos no está disponible.");
        }
    }

    // Método para descubrir datos disponibles en la base seleccionada
    public void mostrarDatosDisponibles() {
        if (baseDatosSeleccionada != null) {
            System.out.println("Conjuntos de datos en " + baseDatosSeleccionada + ":");
            // Aquí se listarían los conjuntos de datos, simplificado para el ejemplo
            System.out.println("Listado de datos disponibles...");
        } else {
            System.out.println("No se ha seleccionado ninguna base de datos.");
        }
    }

    // Flujo alternativo: manejo de error de conexión
    public void gestionarErrorConexion() {
        System.out.println("Error de conexión: Revise la configuración e intente nuevamente.");
    }
}
