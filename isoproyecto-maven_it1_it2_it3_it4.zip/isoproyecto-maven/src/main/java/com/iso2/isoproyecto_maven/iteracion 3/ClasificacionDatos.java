import java.util.ArrayList;
import java.util.List;

// Clase para CDU5: Clasificar los datos en categorías (confidencial, no confidencial, etc.)
public class ClasificacionDatos {

    private String categoria;
    private List<String> conjuntosDatos;
    
    public ClasificacionDatos(String categoria) {
        this.categoria = categoria;
        this.conjuntosDatos = new ArrayList<>();
    }

    // RF.PD.03: Clasificar y categorizar datos en el proyecto
    public void clasificarDato(String dato) {
        if (!conjuntosDatos.contains(dato)) {
            conjuntosDatos.add(dato);
            System.out.println("Dato clasificado en la categoría: " + categoria);
        } else {
            System.out.println("El dato ya está clasificado en esta categoría.");
        }
    }

    public void mostrarClasificacion() {
        System.out.println("Categoría: " + categoria);
        conjuntosDatos.forEach(dato -> 
            System.out.println("Dato clasificado: " + dato)
        );
    }
}
